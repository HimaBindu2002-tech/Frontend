import React from "react";

const LoadingComponent = () => {
  return <div>loading</div>;
};

export default LoadingComponent;
